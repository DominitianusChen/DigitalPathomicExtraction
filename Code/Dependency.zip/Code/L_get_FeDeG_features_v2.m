%% given a feature driven cell graphs (FeDeG), we calculate the feature here
%%% this is the second version of FeDeG feature extration
% written by Cheng Lu at July 2019. Cleveland.
% v2 added  1) more features;
%           2) provide the flag for breaking the object into k-groups by specify the k or threshold in featuer space
%           3) use different bandwidthes for space and features
% note, we use CG(cell graph) to represent FeDeG/FLoCk
%%%% features are described below
%%A. features that do not consider cluster types
%%% 1. Overlapped features: overlaped area portion between nearby CG (need to turn CG
%%% into binary component, then cal the overlapped area)
%%% 2. Variation within CG: variation of the size of CG/number of nuclei within a CG (include the single cell as a CG) across the
%%% whole image
%%% 3. Variation wrt to centroid: variation of the distance/size/color/shape of nucleus to the centroid in a CG, so
%%% that each CG has a variation value, then use statistics across the
%%% whole image
%%% 4. Spatial arrangement features: use the centroids of CG or intersected region of CG as node, build global graph, extract the
%%% standard global graph feature
%%% 5. Density features: that capture the density of the CG

%%B. features that consider cluster types
%%% 1. intersection properties/measurement of CGs from different CG Type
%%% 2. NNearest features: enrichement of the neibouhood CGs type
%%% 3. Spatial arrangement features: use the centroids of different types of CG as node, build global graph, extract the
%%%    standard global graph feature

%%% input:
%          clustCent- nuclei cluster centroid that based on nuclei centroid
%          data2clusterXX- for every data point(nuclei location) which cluster it belongs to (numPts)
%          cluster2dataCellXX  - for every cluster which points are in it (numClust)
%% note we assume that the first two dimension of clustCent are location
% dimension
%% note that cluster2dataCell may contain empty elements
function [set_feature,set_feature_name]=L_get_FeDeG_features_v2(clustCent,cluster2dataCell,para)
set_feature_name=[]; idx_feat=1;
set_feature=[];
% nuclei=para.nuclei;
%% turn each CG into polygon by using the centroid of nuclei as polygon vertices
% 1) collect the polygon(FeDeG) in the image. 2)also record the CG info. 3)
% cal the variation of the distance/size/color/shape of nucleus to the centroid in a CG

set_polygon=[]; % a cell structure, each element contain a n-by-2 vector, where n is the number of vertices, 2 is the location x and y of vertices
%%% note that for a single or two cell clusters we treat them seperately
labels_single_and_two_cell_cluster=zeros(1,size(clustCent,2));

% for recording the CG info.
set_CG_size=ones(1,size(clustCent,2));
set_nuclei_num_in_CG=ones(1,size(clustCent,2));
% only consider the CG has more than 3 cells, the others will put 0, and will be ignored when compute the actual feature
set_variation_distance_2_centroid_of_CG=zeros(1,size(clustCent,2));
% this is accounting for the variation of other attributes, the first
% dimension is the number of CG, seconde dimension is the feature(attribute)
set_variation_other_attribute_2_centroid_of_CG=zeros(size(clustCent,2),size(para.data_other_attribute,1));

for i=1:size(clustCent,2)
    cur_cluster2data=cluster2dataCell{i};
    cur_centroid=[];
    cur_attribute=[];
    for j=1:length(cur_cluster2data)
        cur_centroid(j,:)=para.properties(cur_cluster2data(j)).Centroid;
        if ~isempty(para.data_other_attribute)
            cur_attribute(j,:)=para.data_other_attribute(:,cur_cluster2data(j))';
        end
    end
    % use the convex hull algorithm to determine the outter bound of a CG
    if size(cur_centroid,1)>3
        K=convhull (cur_centroid(:,1),cur_centroid(:,2));
        set_polygon{i}=[cur_centroid(K,1),cur_centroid(K,2)];
        set_CG_size(i)=polyarea(cur_centroid(K,1),cur_centroid(K,2));
        set_nuclei_num_in_CG(i)=size(cur_centroid,1);
        
        cur_mean_centroid=mean([cur_centroid(:,1),cur_centroid(:,2)]);
        set_variation_distance_2_centroid_of_CG(i)= std(sqrt((cur_centroid(:,1)-cur_mean_centroid(1)).^2+(cur_centroid(:,2)-cur_mean_centroid(2)).^2));
        
        if ~isempty(para.data_other_attribute)
            cur_mean_attribute=mean(cur_attribute);
            set_variation_other_attribute_2_centroid_of_CG(i,:)=std(abs(cur_attribute-repmat(cur_mean_attribute,size(cur_attribute,1),1)));
        end
    else %for a single or two cell clusters
        set_polygon{i}=cur_centroid;
        labels_single_and_two_cell_cluster(i)=1;
        % use a proximate nuclei size as the CG size
        if size(cur_centroid,1)==1
            tmp=para.nuclei{cur_cluster2data};
            set_polygon{i}=[tmp(:,2) tmp(:,1)];% use the nuclei boundary as polygon for CG with singel cell
            set_CG_size(i)=para.properties(cur_cluster2data).Area;
        end
        if size(cur_centroid,1)==2
            tmp1=para.nuclei{cur_cluster2data(1)};
            tmp2=para.nuclei{cur_cluster2data(2)};
            tmp=[tmp1;tmp2];
            cur_centroid=[tmp(:,2) tmp(:,1)];
            K=convhull (cur_centroid(:,1),cur_centroid(:,2));
            set_polygon{i}=[cur_centroid(K,1),cur_centroid(K,2)];
            set_CG_size(i)=polyarea(cur_centroid(K,1),cur_centroid(K,2));
            %             set_CG_size(i)=para.properties(cur_cluster2data(1)).Area+para.properties(cur_cluster2data(2)).Area;
        end
    end
    %     set_polygon{i}=cur_centroid;
    
    % % check
    if para.debug
        %         figure;hold on;
        %         plot(cur_centroid(:,1),cur_centroid(:,2),'r');plot(cur_centroid(K,1),cur_centroid(K,2),'b');
        %         hold off;
        %
        %         %% display nuclei and nuclei area
        %                   I=para.I; nuclei=para.nuclei;
        %                   show(I,1);hold on;
        %                   for k = 1:length(nuclei)
        %                       plot(nuclei{k}(:,2), nuclei{k}(:,1), 'g-', 'LineWidth', 2);
        %                   end
        %                   hold off;
    end
end
%%% prepare the cell location information in FM
AlldataPts=[];
tempC=[para.properties.Centroid];
AlldataPts(1:length(tempC)/2,1)=tempC(1:2:end);
AlldataPts(1:length(tempC)/2,2)=tempC(2:2:end);
dataPts=AlldataPts(:,1:2);
FM=dataPts(:,1:2)'; % nuclei centroid

%%  calculate the intersection and record the intersection information between each pair of CG
set_intersection_CG_idx_pair=[]; idx_ICG=1;
% record the intersection information, the relative portion depends on which CG to be in the denominator, have two possible values, smaller one we put in XX_small
set_intersection_CG_relative_portion_small=[];
set_intersection_CG_relative_portion_large=[];
set_intersection_CG_absolute_value=[];
set_intersection_CG_centroid=[];

d=squareform(pdist(clustCent(1:2,:)'));
d(d==0)=Inf;

for i=1:length(set_polygon)-1
    cur_polygon_i=set_polygon{i};
    [val,ind]=sort(d(i,:),'ascend');
    set_polygon_NN30_idx=ind(1:min(30,length(ind)));%check it's 30 neighbours
    set_polygon_NN30=set_polygon(set_polygon_NN30_idx);
    for j=1:length(set_polygon_NN30)
        cur_polygon_j=set_polygon_NN30{j};
        if ~isempty(cur_polygon_i)&&~isempty(cur_polygon_j)
        % cal intersection only if the CG contain more than 2 cells
        %         if ~(labels_single_and_two_cell_cluster(i)||labels_single_and_two_cell_cluster(j))
        [cur_polygon_intersect_x,cur_polygon_intersect_y]= polybool('intersection',cur_polygon_i(:,1),cur_polygon_i(:,2),cur_polygon_j(:,1),cur_polygon_j(:,2));
        cur_polygon_intersect=[cur_polygon_intersect_x,cur_polygon_intersect_y];
        cur_polygon_intersect(sum(isnan(cur_polygon_intersect),2)>0,:)=[];
        % debug and visualize
        if para.debug
            cur_cluster2data_i=cluster2dataCell{i};
            cur_cluster2data_j=cluster2dataCell{set_polygon_NN30_idx(j)};
            
            cmap=colormap('hsv');
            %             figure;
            show(para.I,1);hold on;
            for k=1:length(cur_cluster2data_i)
                if isfield(para,'nuclei');
                    plot(para.nuclei{cur_cluster2data_i(k)}(:,2), para.nuclei{cur_cluster2data_i(k)}(:,1), 'g-', 'LineWidth', 1);
                end
                plot([clustCent(1,i), FM(1,cur_cluster2data_i(k))],[clustCent(2,i), FM(2,cur_cluster2data_i(k))],'Color',cmap(mod(i,size(cmap,1))+1,:), 'LineWidth',3);
            end
            
            for k=1:length(cur_cluster2data_j)
                if isfield(para,'nuclei');
                    plot(para.nuclei{cur_cluster2data_j(k)}(:,2), para.nuclei{cur_cluster2data_j(k)}(:,1), 'y-', 'LineWidth', 1);
                end
                plot([clustCent(1,set_polygon_NN30_idx(j)), FM(1,cur_cluster2data_j(k))],[clustCent(2,set_polygon_NN30_idx(j)), FM(2,cur_cluster2data_j(k))],'Color',cmap(mod(set_polygon_NN30_idx(j),size(cmap,1))+1,:), 'LineWidth',3);
            end
            phandle_i=patch(cur_polygon_i(:,1),cur_polygon_i(:,2),cmap(mod(i,size(cmap,1))+1,:));
            phandle_j=patch(cur_polygon_j(:,1),cur_polygon_j(:,2),cmap(mod(set_polygon_NN30_idx(j),size(cmap,1))+1,:));
            transparency=0.3;  % values between 0 and 1
            alpha(phandle_i,transparency);
            alpha(phandle_j,transparency);
            
            % plot(cur_polygon_i(:,1),cur_polygon_i(:,2),'r');
            % plot(cur_polygon_j(:,1),cur_polygon_j(:,2),'b');
        end
        
        %%% if we found CGs that have intersection, record the
        %%% information
        if ~isempty(cur_polygon_intersect)
            set_intersection_CG_idx_pair(idx_ICG,:)=[i set_polygon_NN30_idx(j)];
            % record the intersection information, the relative portion depends on which CG to be in the denominator, have two possible values, smaller one we put in XX_small
            area_intersect=polyarea(cur_polygon_intersect(:,1),cur_polygon_intersect(:,2));
            set_intersection_CG_relative_portion_small(idx_ICG)=min(area_intersect/polyarea(cur_polygon_i(:,1),cur_polygon_i(:,2)),area_intersect/polyarea(cur_polygon_j(:,1),cur_polygon_j(:,2)));
            set_intersection_CG_relative_portion_large(idx_ICG)=max(area_intersect/polyarea(cur_polygon_i(:,1),cur_polygon_i(:,2)),area_intersect/polyarea(cur_polygon_j(:,1),cur_polygon_j(:,2)));
            set_intersection_CG_absolute_value(idx_ICG)=area_intersect;
            
            set_intersection_CG_centroid(idx_ICG,:)=mean(cur_polygon_intersect);
            idx_ICG=idx_ICG+1;
        end
        %         else
        %
        %         end
        end
    end
end
%% A. features that do not consider cluster types
%% 1. intersection properties/measurement of CGs or overlaped area portion between nearby CG
%     the feature name should be informative so that we know what feature
%     it is
% if isempty(set_intersection_CG_absolute_value)
%     set_feature=zeros
%     idx_feat=length(set_feature)+1;
% else
set_feature(idx_feat)=(idx_ICG-1)/size(clustCent,2);
set_feature_name{idx_feat}='FeDeG-portion of intersected CG';% note that this feature can be greater than 1 since one CG can have intersection with more than one CG
idx_feat=idx_feat+1;

set_feature(idx_feat)=(idx_ICG-1);
set_feature_name{idx_feat}='FeDeG-abs. number of intersected CG';
idx_feat=idx_feat+1;

T=0.1:0.1:0.9;
for i=1:length(T)
    set_feature(idx_feat)=sum((set_intersection_CG_relative_portion_large>T(i)))/size(clustCent,2);
    set_feature_name{idx_feat}=sprintf('FeDeG-portion of highly intersected CG:T=%.1f',T(i));
    idx_feat=idx_feat+1;
end

for i=1:length(T)
    set_feature(idx_feat)=sum((set_intersection_CG_relative_portion_large>T(i)));
    set_feature_name{idx_feat}=sprintf('FeDeG-number of highly intersected CG:T=%.1f',T(i));
    idx_feat=idx_feat+1;
end

%%% statistics on the intersection area
statisti_name = [{'mean'} {'median'} {'std'} {'range'} {'min'} {'max'} {'kurtosis'} {'skewness'} ];
%the format is like this: FeDeG-statistcname(intersection area)


for mi = 1:numel(statisti_name)
    if isempty(set_intersection_CG_relative_portion_small)
        set_feature(idx_feat)=0;
    else
        set_feature(idx_feat)=eval(sprintf('%s(set_intersection_CG_relative_portion_small)',statisti_name{mi}));
    end
    set_feature_name{idx_feat} = ['FeDeG-' statisti_name{mi} '(' 'intersection area portion:small' ')'  ];
    idx_feat=idx_feat+1;
end

for mi = 1:numel(statisti_name)
    if isempty(set_intersection_CG_relative_portion_large)
        set_feature(idx_feat)=0;
    else
        set_feature(idx_feat)=eval(sprintf('%s(set_intersection_CG_relative_portion_large)',statisti_name{mi}));
    end
    set_feature_name{idx_feat} = ['FeDeG-' statisti_name{mi} '(' 'intersection area portion:large' ')'  ];
    idx_feat=idx_feat+1;
end

for mi = 1:numel(statisti_name)
    if isempty(set_intersection_CG_absolute_value)
        set_feature(idx_feat)=0;
    else
        set_feature(idx_feat)=eval(sprintf('%s(set_intersection_CG_absolute_value)',statisti_name{mi}));
    end
    set_feature_name{idx_feat} = ['FeDeG-' statisti_name{mi} '(' 'intersection area abs val' ')'  ];
    idx_feat=idx_feat+1;
end

for mi = 1:numel(statisti_name)
    if isempty(set_intersection_CG_relative_portion_small)
        set_feature(idx_feat)=0;
    else
        set_feature(idx_feat)=eval(sprintf('%s((set_intersection_CG_relative_portion_large+set_intersection_CG_relative_portion_small)/2)',...
            statisti_name{mi}));
    end
    set_feature_name{idx_feat} = ['FeDeG-' statisti_name{mi} '(' 'intersection area portion:mean' ')'  ];
    idx_feat=idx_feat+1;
end
% end
%% 2. statistics of the size of CG/number of nuclei within a CG (include the single cell as a CG) across the
%%% whole image
for mi = 1:numel(statisti_name)
    set_feature(idx_feat)=eval(sprintf('%s(set_CG_size)',statisti_name{mi}));
    set_feature_name{idx_feat} = ['FeDeG-' statisti_name{mi} '(' 'size of all CG' ')'  ];
    idx_feat=idx_feat+1;
end

% statistics of CG that exclude the CG has one or two cells
for mi = 1:numel(statisti_name)
    if isempty(find(~labels_single_and_two_cell_cluster, 1))
        set_feature(idx_feat)=0;
    else
        set_feature(idx_feat)=eval(sprintf('%s(set_CG_size(~labels_single_and_two_cell_cluster))',...
            statisti_name{mi}));
    end
    set_feature_name{idx_feat} = ['FeDeG-' statisti_name{mi} '(' 'size of non-1-2cell CG' ')'  ];
    idx_feat=idx_feat+1;
end

set_feature(idx_feat)=sum(~labels_single_and_two_cell_cluster)/length(labels_single_and_two_cell_cluster);
set_feature_name{idx_feat}=sprintf('FeDeG-non-1-2cell CG ratio');
idx_feat=idx_feat+1;

for mi = 1:numel(statisti_name)
    set_feature(idx_feat)=eval(sprintf('%s(set_nuclei_num_in_CG)',...
        statisti_name{mi}));
    set_feature_name{idx_feat} = ['FeDeG-' statisti_name{mi} '(' 'nuclei no. in CG' ')'  ];
    idx_feat=idx_feat+1;
end
%% 3. variation of the distance/size/color/shape of nucleus to the centroid in a CG (CG has >=3 cells), so
%%% that each CG has a variation value, then use statistics across the
%%% whole image, this group of features maybe trivial, since the CG are
%%% form by the predefined bandwidth.
if ~isempty(para.data_other_attribute)
    for t=1:size(set_variation_other_attribute_2_centroid_of_CG,2)
        cur_att=set_variation_other_attribute_2_centroid_of_CG(:,t);
        for mi = 1:numel(statisti_name)
            if isempty(eval(sprintf('%s(cur_att(cur_att>0))',...
                    statisti_name{mi})))
                set_feature(idx_feat)=0;
            else
                set_feature(idx_feat)=eval(sprintf('%s(cur_att(cur_att>0))',...
                    statisti_name{mi}));
            end
            set_feature_name{idx_feat} = ['FeDeG-' statisti_name{mi} '(' 'var of nuclear feat' num2str(t) 'to the centroid'  ')'  ];
            idx_feat=idx_feat+1;
        end
    end
end

for mi = 1:numel(statisti_name)
    if isempty(eval(sprintf('%s(set_variation_distance_2_centroid_of_CG(set_variation_distance_2_centroid_of_CG>0))',...
            statisti_name{mi})))
        set_feature(idx_feat)=0;
    else
        set_feature(idx_feat)=eval(sprintf('%s(set_variation_distance_2_centroid_of_CG(set_variation_distance_2_centroid_of_CG>0))',...
            statisti_name{mi}));
    end
    set_feature_name{idx_feat} = ['FeDeG-' statisti_name{mi} '(' 'var of cell to CG centroid' ')'  ];
    idx_feat=idx_feat+1;
end
%% 4. Spatial arrangement features: use the centroids of CG as node, build global graph, extract the
%%% standard global graph feature
if length(set_intersection_CG_centroid)>8
    [vfeature,GraphFeatureDescription] = get_graph_features(clustCent(1,:)',clustCent(2,:)');
else % can't compute the features, and put all zeros
    vfeature=zeros(1,51);
    load('GraphFeatureDescription.mat')
end
set_feature=cat(2,set_feature,vfeature);

% idx_fea_name=length(set_feature_name)+1;
for i=1:length(GraphFeatureDescription)
    curname=GraphFeatureDescription{i};
    curnew=['FeDeG-CG centroid-' curname];
    set_feature_name{idx_feat}=curnew;
    %     idx_fea_name=idx_fea_name+1;
    idx_feat=idx_feat+1;
end

%%% use the centroids of intersected region of CG as node, build global graph, extract the
%%% standard global graph feature
if length(set_intersection_CG_centroid)>8
    %     try
    [vfeature,GraphFeatureDescription] = get_graph_features(set_intersection_CG_centroid(:,1),set_intersection_CG_centroid(:,2));
    %     catch
    %         display('error');
    %     end
else % can't compute the features, and put all zeros
    vfeature=zeros(1,51);
    load('GraphFeatureDescription.mat')
end

set_feature=cat(2,set_feature,vfeature);
% idx_fea_name=length(set_feature_name)+1;
for i=1:length(GraphFeatureDescription)
    curname=GraphFeatureDescription{i};
    curnew=['FeDeG-intersected CG centroid-' curname];
    set_feature_name{idx_feat}=curnew;
    %     idx_fea_name=idx_fea_name+1;
    idx_feat=idx_feat+1;
end
%% 5. Density features: that capture the density of the CG,
%%% cal the density for CGs have >3 cells and all CGs
%%% the density will be the number of object(nuclei) / number of pixels the
%%% CG taken

% statistics of density of CG that exclude the CG has one or two cells
for mi = 1:numel(statisti_name)
    if isempty(find(~labels_single_and_two_cell_cluster, 1))
        set_feature(idx_feat)=0;
    else
        set_feature(idx_feat)=eval(sprintf('%s(set_nuclei_num_in_CG(~labels_single_and_two_cell_cluster)./set_CG_size(~labels_single_and_two_cell_cluster))',...
            statisti_name{mi}));
    end
    set_feature_name{idx_feat} = ['FeDeG-' statisti_name{mi} '(' 'density of non-1-2cell CGs' ')'  ];
    idx_feat=idx_feat+1;
end

% statistics of density of all CGs
for mi = 1:numel(statisti_name)
    set_feature(idx_feat)=eval(sprintf('%s(set_nuclei_num_in_CG./set_CG_size)',...
        statisti_name{mi}));
    set_feature_name{idx_feat} = ['FeDeG-' statisti_name{mi} '(' 'density of all CGs' ')'  ];
    idx_feat=idx_feat+1;
end
% set_feature_name=set_feature_name';

%% B. features that consider cluster types
%%% 1. intersection properties/measurement of CGs from different CG Type
%%% 2. NNearest features/Distance to other clusters features:
%%% 3. Encompass features:

if para.num_fixed_types>1
    %% 1. intersection properties/measurement of CGs from different CG Type
    %     set_intersection_CG_idx_pair
    %     para.clust2types
    
    %     label_1intra_2inter_Type_intersect=para.clust2types(set_intersection_CG_idx_pair(:,1))==para.clust2types(set_intersection_CG_idx_pair(:,2));
    set_intersection_CG_idx_pair_inCGType=para.clust2types(set_intersection_CG_idx_pair);
    for iType=1:para.num_fixed_types
        if ~isempty(find(sum(set_intersection_CG_idx_pair_inCGType==iType,2)==2, 1))
            % intra-type
            set_feature(idx_feat)=sum(sum(set_intersection_CG_idx_pair_inCGType==iType,2)==2)/sum(para.clust2types==iType);
        else
            set_feature(idx_feat)=0;
        end
        set_feature_name{idx_feat}=['FeDeG-portion of intra-type CG intersction-Type' num2str(iType)];
        idx_feat=idx_feat+1;
        
        if ~isempty(find(sum(set_intersection_CG_idx_pair_inCGType~=iType,2)==2, 1))
            % inter-type
            set_feature(idx_feat)=sum(sum(set_intersection_CG_idx_pair_inCGType~=iType,2)==2)/sum(para.clust2types==iType);
        else
            set_feature(idx_feat)=0;
        end
        set_feature_name{idx_feat}=['FeDeG-portion of inter-type CG intersction-Type' num2str(iType)];
        idx_feat=idx_feat+1;
    end
    
    for iType=1:para.num_fixed_types
        if ~isempty(find(sum(set_intersection_CG_idx_pair_inCGType==iType,2)==2, 1))
            % intra-type
            set_feature(idx_feat)=sum(sum(set_intersection_CG_idx_pair_inCGType==iType,2)==2);
        else
            set_feature(idx_feat)=0;
        end
        set_feature_name{idx_feat}=['FeDeG-number of intra-type CG intersction-Type' num2str(iType)];
        idx_feat=idx_feat+1;
        
        if ~isempty(find(sum(set_intersection_CG_idx_pair_inCGType~=iType,2)==2, 1))
            % inter-type
            set_feature(idx_feat)=sum(sum(set_intersection_CG_idx_pair_inCGType~=iType,2)==2);
        else
            set_feature(idx_feat)=0;
        end
        set_feature_name{idx_feat}=['FeDeG-number of inter-type CG intersction-Type' num2str(iType)];
        idx_feat=idx_feat+1;
    end
    
    %% 2. NNearest features: enrichement of the neibouhood CGs type
    nset=[5;10;15];
    d=squareform(pdist(clustCent(1:2,:)'));
    d(d==0)=Inf;
    numClust=size(clustCent,2);
    for n=1:length(nset)
        curClust=[];
        if length(d)>nset(n)
            for i=1:numClust
                [~,ind]=sort(d(i,:),'ascend');
                curClust(i)=sum(para.clust2types(ind(1:nset(n)))~=para.clust2types(i))/nset(n);
            end
            for mi = 1:numel(statisti_name)
                set_feature(idx_feat)=eval(sprintf('%s(curClust)',...
                    statisti_name{mi}));
                set_feature_name{idx_feat} = ['FeDeG-' statisti_name{mi} '(' 'portion of other CG types in' num2str(nset(n)) 'nearest neighbors' ')'  ];
                idx_feat=idx_feat+1;
            end
        else
            for mi = 1:numel(statisti_name)
                set_feature(idx_feat)=NaN;
                set_feature_name{idx_feat} = ['FeDeG-' statisti_name{mi} '(' 'portion of other CG types in' num2str(nset(n)) 'nearest neighbors' ')'  ];
                idx_feat=idx_feat+1;
            end
        end
    end
    %% 3. Spatial arrangement features: use the centroids of different types of CG as node, build global graph, extract the
    %%% standard global graph feature
    % setClusterCenters=clustCent(1:2,:);
    for i=1:para.num_fixed_types
        if sum(para.clust2types==i)>8
            [vfeature,GraphFeatureDescription] = get_graph_features(clustCent(1,para.clust2types==i)',...
                clustCent(2,para.clust2types==i)');
        else % can't compute the features, and put all zeros
            vfeature=zeros(1,51);
        end
        set_feature=cat(2,set_feature,vfeature);
        % idx_fea_name=length(set_feature_name)+1;
        
        for j=1:length(GraphFeatureDescription)
            curname=GraphFeatureDescription{j};
            curnew=['FeDeG-Type' num2str(i) 'CG centroid-' curname];
            set_feature_name{idx_feat}=curnew;
            %     idx_fea_name=idx_fea_name+1;
            idx_feat=idx_feat+1;
        end
    end
end

