% we use mean shif on pre-seg nuclei to form the FeDeG
% try to cluster nuclei to form local groups
% we run mean shift one time only
% can use advanced meanshift for better result?
%%% adaptive meanshift?
%%% feature weighted meanshift?
% -input:
%         para.feature_space
%         para.bandWidth_space
%         para.bandWidth_features
%         para.num_fixed_types - if provide a fixed number of types, 0
%                                means no subtype number predefined. 2
%                                means group all the FeDeG into two types.
%                                can set to any number which maybe
%                                meaningful for the type of image you have
%                                at hand. also need to consider the
%                                bandwith in feature space at the same time.
% -ouput:
%          clustCent- nuclei cluster centroid that based on nuclei centroid
%          data2clusterXX- for every data point which cluster it belongs to (numPts)
%          cluster2dataCellXX  - for every cluster which points are in it (numClust)
%          XXXXXX_filtered - for the filtered data (not complete)
%          data_other_attribute- return the attributes used for
%                                constructing FeDeG other than location, e.g., if you used
%                               'Centroid+Area', then the Area will be
%                               returned. this will be used in cal the
%                               feature in L_get_FeDeG_features function
%           clust2types - nuclei cluster centroids to the type corresponding while para.num_fixed_types>1
%           typeCent - the type center on feature sapce
% v2 can specify different bandwidth for coordination space Hs, and feature space Hf
function  [clustCent,data2cluster,cluster2dataCell,data_other_attribute,clust2types,typeCent]=Lconstruct_FeDeG_v2(curIM,para)
% addpath('C:\Nutstore\Nutstore\PathImAnalysis_Program\Program\Segmentation\GeneralLoG');
% ss=regionprops(bw_Nuclei,'Centroid','Area','Eccentricity','Solidity'); %show(bw_Nuclei);
ss=para.properties;
% nuclei=para.nuclei;
%% location only meanshift clustering
if strcmp(para.feature_space,'Centroid')
    AlldataPts=[];
    tempC=[ss.Centroid];
    AlldataPts(1:length(ss),1)=tempC(1:2:end);
    AlldataPts(1:length(ss),2)=tempC(2:2:end);
    %     idxF=3;
    %     AlldataPts(:,idxF)=[ss.Area];   idxF=idxF+1;
    %     AlldataPts(:,idxF)=[ss.Eccentricity]; idxF=idxF+1;
    %     AlldataPts(:,idxF)=[ss.Solidity]; idxF=idxF+1;
    %
    dataPts=AlldataPts(:,1:2);
    
    [clustCent,data2cluster,cluster2dataCell,clust2types,typeCent] = MeanShiftCluster_v2(dataPts',para.bandWidth_space, para.bandWidth_features,para.num_fixed_types);
    FM=dataPts(:,1:2)';
    data_other_attribute=[];
end

% if strcmp(para.feature_space,'Area')
%     idxF=1;
%     AlldataPts=[];
%     AlldataPts(:,idxF)=[ss.Area];   idxF=idxF+1;
%     AlldataPts(:,idxF)=[ss.MeanIntensity]; idxF=idxF+1;
%
%     dataPts=AlldataPts;
%
%     bandWidth=5;
%     [clustCent,data2cluster,cluster2dataCell,clust2types,typeCent] = MeanShiftCluster_v2(dataPts',bandWidth);
%
%     AlldataPts=[];
%     tempC=[ss.Centroid];
%     AlldataPts(1:length(ss),1)=tempC(1:2:end);
%     AlldataPts(1:length(ss),2)=tempC(2:2:end);
%     FM=AlldataPts(:,1:2)';
%
%     clustCentReal=[];
%     for t=1:length(cluster2dataCell)
%         cur=cluster2dataCell{t};
%         clustCentReal(:,t)=mean(FM(:,cur),2);
%     end
%      %%% on color image
%     show(curIM,8);
%     cmap=colormap('jet');
%     hold on
%     numObj=size(FM,2);
%     for k = 1 : numObj
%         plot(nuclei{k}(:,2), nuclei{k}(:,1), 'g-', 'LineWidth', 1);
%
%         % connecting line
%         plot([clustCentReal(1,data2cluster(k)), FM(1,k)],[clustCentReal(2,data2cluster(k)), FM(2,k)],  'Color',cmap(mod(data2cluster(k),size(cmap,1))+1,:),'LineWidth',1);
%     end
%     hold off
% end

%% location ?? area  meanshift clustering
if strcmp(para.feature_space,'Centroid-Area')
    AlldataPts=[];
    tempC=[ss.Centroid];
    AlldataPts(1:length(ss),1)=tempC(1:2:end);
    AlldataPts(1:length(ss),2)=tempC(2:2:end);
    idxF=3;
    AlldataPts(:,idxF)=[ss.Area];   %idxF=idxF+1;
    %     AlldataPts(:,idxF)=[ss.Eccentricity]; idxF=idxF+1;
    %     AlldataPts(:,idxF)=[ss.Solidity]; idxF=idxF+1;
    %
    dataPts=AlldataPts(:,1:3);
    
    
    [clustCent,data2cluster,cluster2dataCell,clust2types,typeCent] = MeanShiftCluster_v2(dataPts',para.bandWidth_space, para.bandWidth_features,para.num_fixed_types);
    FM=dataPts(:,1:2)';
    
    data_other_attribute=dataPts(:,3:end)';
    %     % show low level ms result
    %     if para.debug
    %         LshowBWonIM(bwGT,curIM,1);
    %         hold on
    %         numObj=size(FM,2);
    %         for k = 1 : numObj
    %             plot(FM(1,k), FM(2,k), 'c*');%,'MarkerSize',10);
    %             plot(clustCent(1,data2cluster(k)),clustCent(2,data2cluster(k)), 'rp','MarkerSize',10,'MarkerFaceColor','g');
    %             % connecting line
    %             plot([clustCent(1,data2cluster(k)), FM(1,k)],[clustCent(2,data2cluster(k)), FM(2,k)], 'b','LineWidth',1);
    %         end
    %         hold off
    %     end
end
%% with shape
if strcmp(para.feature_space,'Centroid-Area-Eccentricity')
    dataPts=[];
    tempC=[ss.Centroid];
    dataPts(1:length(ss),1)=tempC(1:2:end);
    dataPts(1:length(ss),2)=tempC(2:2:end);
    idxF=3;
    dataPts(:,idxF)=[ss.Area];   idxF=idxF+1;
    dataPts(:,idxF)=[ss.Eccentricity]; idxF=idxF+1;
    %     dataPts(:,idxF)=[ss.MeanIntensity]; idxF=idxF+1;
    
    
    [clustCent,data2cluster,cluster2dataCell,clust2types,typeCent] = MeanShiftCluster_v2(dataPts',para.bandWidth_space, para.bandWidth_features,para.num_fixed_types);
    FM=dataPts(:,1:2)';
    data_other_attribute=dataPts(:,3:end)';
    %     LshowBWonIM(bwGT,curIM,2);
    %     hold on
    %     numObj=size(FM,2);
    %     for k = 1 : numObj
    %         plot(FM(1,k), FM(2,k), 'c*');%,'MarkerSize',10);
    %         plot(clustCent(1,data2cluster(k)),clustCent(2,data2cluster(k)), 'rp','MarkerSize',10,'MarkerFaceColor','g');
    %         % connecting line
    %         plot([clustCent(1,data2cluster(k)), FM(1,k)],[clustCent(2,data2cluster(k)), FM(2,k)], 'b','LineWidth',1);
    %     end
    %     hold off
end
%% with Area and Intensity
if strcmp(para.feature_space,'Centroid-Area-MeanIntensity')
    dataPts=[];
    tempC=[ss.Centroid];
    dataPts(1:length(ss),1)=tempC(1:2:end);
    dataPts(1:length(ss),2)=tempC(2:2:end);
    idxF=3;
    dataPts(:,idxF)=[ss.Area];   idxF=idxF+1;
    %     dataPts(:,idxF)=[ss.Eccentricity]; idxF=idxF+1;
    dataPts(:,idxF)=[ss.MeanIntensity]; idxF=idxF+1;
    
    
    [clustCent,data2cluster,cluster2dataCell,clust2types,typeCent] = MeanShiftCluster_v2(dataPts',para.bandWidth_space, para.bandWidth_features,para.num_fixed_types);
    FM=dataPts(:,1:2)';
    data_other_attribute=dataPts(:,3:end)';
    %     LshowBWonIM(bwGT,curIM,2);
    %     hold on
    %     numObj=size(FM,2);
    %     for k = 1 : numObj
    %         plot(FM(1,k), FM(2,k), 'c*');%,'MarkerSize',10);
    %         plot(clustCent(1,data2cluster(k)),clustCent(2,data2cluster(k)), 'rp','MarkerSize',10,'MarkerFaceColor','g');
    %         % connecting line
    %         plot([clustCent(1,data2cluster(k)), FM(1,k)],[clustCent(2,data2cluster(k)), FM(2,k)], 'b','LineWidth',1);
    %     end
    %     hold off
end

%% with Intensity
if strcmp(para.feature_space,'Centroid-MeanIntensity')
    dataPts=[];
    tempC=[ss.Centroid];
    dataPts(1:length(ss),1)=tempC(1:2:end);
    dataPts(1:length(ss),2)=tempC(2:2:end);
    idxF=3;
    %     dataPts(:,idxF)=[ss.Area];   idxF=idxF+1;
    %     dataPts(:,idxF)=[ss.Eccentricity]; idxF=idxF+1;
    dataPts(:,idxF)=[ss.MeanIntensity]; idxF=idxF+1;
    
    
    [clustCent,data2cluster,cluster2dataCell,clust2types,typeCent] = MeanShiftCluster_v2(dataPts',para.bandWidth_space, para.bandWidth_features,para.num_fixed_types);
    %         [clustCent,data2cluster,cluster2dataCell,clust2types,typeCent] = MeanShiftCluster_v2(dataPts',bandWidth,1);
    
    FM=dataPts(:,1:2)';
    data_other_attribute=dataPts(:,3:end)';
    %     LshowBWonIM(bwGT,curIM,2);
    %     hold on
    %     numObj=size(FM,2);
    %     for k = 1 : numObj
    %         plot(FM(1,k), FM(2,k), 'c*');%,'MarkerSize',10);
    %         plot(clustCent(1,data2cluster(k)),clustCent(2,data2cluster(k)), 'rp','MarkerSize',10,'MarkerFaceColor','g');
    %         % connecting line
    %         plot([clustCent(1,data2cluster(k)), FM(1,k)],[clustCent(2,data2cluster(k)), FM(2,k)], 'b','LineWidth',1);
    %     end
    %     hold off
end

%% with eccentricity, note that eccentricity may not be a good measure for shape
if strcmp(para.feature_space,'Centroid-Eccentricity')
    dataPts=[];
    tempC=[ss.Centroid];
    dataPts(1:length(ss),1)=tempC(1:2:end);
    dataPts(1:length(ss),2)=tempC(2:2:end);
    idxF=3;
    %     dataPts(:,idxF)=[ss.Area];   idxF=idxF+1;
    dataPts(:,idxF)=[ss.Eccentricity]; idxF=idxF+1;
    %     dataPts(:,idxF)=[ss.MeanIntensity]; idxF=idxF+1;
    
    
    [clustCent,data2cluster,cluster2dataCell,clust2types,typeCent] = MeanShiftCluster_v2(dataPts',para.bandWidth_space, para.bandWidth_features,para.num_fixed_types);
    FM=dataPts(:,1:2)';
    data_other_attribute=dataPts(:,3:end)';
    %     LshowBWonIM(bwGT,curIM,2);
    %     hold on
    %     numObj=size(FM,2);
    %     for k = 1 : numObj
    %         plot(FM(1,k), FM(2,k), 'c*');%,'MarkerSize',10);
    %         plot(clustCent(1,data2cluster(k)),clustCent(2,data2cluster(k)), 'rp','MarkerSize',10,'MarkerFaceColor','g');
    %         % connecting line
    %         plot([clustCent(1,data2cluster(k)), FM(1,k)],[clustCent(2,data2cluster(k)), FM(2,k)], 'b','LineWidth',1);
    %     end
    %     hold off
end
%% with longness
if strcmp(para.feature_space,'Centroid-Longness')
    dataPts=[];
    tempC=[ss.Centroid];
    dataPts(1:length(ss),1)=tempC(1:2:end);
    dataPts(1:length(ss),2)=tempC(2:2:end);
    idxF=3;
    %     dataPts(:,idxF)=[ss.Area];   idxF=idxF+1;
    dataPts(:,idxF)=[ss.MajorAxisLength]./[ss.MinorAxisLength]; idxF=idxF+1;
    %     dataPts(:,idxF)=[ss.MeanIntensity]; idxF=idxF+1;
    
    
    [clustCent,data2cluster,cluster2dataCell,clust2types,typeCent] = MeanShiftCluster_v2(dataPts',para.bandWidth_space, para.bandWidth_features,para.num_fixed_types);
    FM=dataPts(:,1:2)';
    data_other_attribute=dataPts(:,3:end)';
    %     LshowBWonIM(bwGT,curIM,2);
    %     hold on
    %     numObj=size(FM,2);
    %     for k = 1 : numObj
    %         plot(FM(1,k), FM(2,k), 'c*');%,'MarkerSize',10);
    %         plot(clustCent(1,data2cluster(k)),clustCent(2,data2cluster(k)), 'rp','MarkerSize',10,'MarkerFaceColor','g');
    %         % connecting line
    %         plot([clustCent(1,data2cluster(k)), FM(1,k)],[clustCent(2,data2cluster(k)), FM(2,k)], 'b','LineWidth',1);
    %     end
    %     hold off
end

%% with Circularity
if strcmp(para.feature_space,'Centroid-Circularity')
    dataPts=[];
    tempC=[ss.Centroid];
    dataPts(1:length(ss),1)=tempC(1:2:end);
    dataPts(1:length(ss),2)=tempC(2:2:end);
    idxF=3;
    dataPts(:,idxF)=[ss.Circularity];   idxF=idxF+1;
    %    dataPts(:,idxF)=[ss.MajorAxisLength]./[ss.MinorAxisLength]; idxF=idxF+1;
    %     dataPts(:,idxF)=[ss.MeanIntensity]; idxF=idxF+1;
    
    
    [clustCent,data2cluster,cluster2dataCell,clust2types,typeCent] = MeanShiftCluster_v2(dataPts',para.bandWidth_space, para.bandWidth_features,para.num_fixed_types);
    FM=dataPts(:,1:2)';
    data_other_attribute=dataPts(:,3:end)';
    %     LshowBWonIM(bwGT,curIM,2);
    %     hold on
    %     numObj=size(FM,2);
    %     for k = 1 : numObj
    %         plot(FM(1,k), FM(2,k), 'c*');%,'MarkerSize',10);
    %         plot(clustCent(1,data2cluster(k)),clustCent(2,data2cluster(k)), 'rp','MarkerSize',10,'MarkerFaceColor','g');
    %         % connecting line
    %         plot([clustCent(1,data2cluster(k)), FM(1,k)],[clustCent(2,data2cluster(k)), FM(2,k)], 'b','LineWidth',1);
    %     end
    %     hold off
end
%% with shape and Intensity
if strcmp(para.feature_space,'Centroid-Area-Eccentricity-MeanIntensity')
    dataPts=[];
    tempC=[ss.Centroid];
    dataPts(1:length(ss),1)=tempC(1:2:end);
    dataPts(1:length(ss),2)=tempC(2:2:end);
    idxF=3;
    dataPts(:,idxF)=[ss.Area];   idxF=idxF+1;
    dataPts(:,idxF)=[ss.Eccentricity]; idxF=idxF+1;
    dataPts(:,idxF)=[ss.MeanIntensity]; idxF=idxF+1;
    
    
    [clustCent,data2cluster,cluster2dataCell,clust2types,typeCent] = MeanShiftCluster_v2(dataPts',para.bandWidth_space, para.bandWidth_features,para.num_fixed_types);
    FM=dataPts(:,1:2)';
    data_other_attribute=dataPts(:,3:end)';
    %     LshowBWonIM(bwGT,curIM,2);
    %     hold on
    %     numObj=size(FM,2);
    %     for k = 1 : numObj
    %         plot(FM(1,k), FM(2,k), 'c*');%,'MarkerSize',10);
    %         plot(clustCent(1,data2cluster(k)),clustCent(2,data2cluster(k)), 'rp','MarkerSize',10,'MarkerFaceColor','g');
    %         % connecting line
    %         plot([clustCent(1,data2cluster(k)), FM(1,k)],[clustCent(2,data2cluster(k)), FM(2,k)], 'b','LineWidth',1);
    %     end
    %     hold off
end
%% show low level ms result
if para.debug
    %     LshowBWonIM(bwGT,curIM,1);
    %%% on color image
    %     show(curIM,8);
    %     hold on
    %     numObj=size(FM,2);
    %     for k = 1 : numObj
    % %         plot(FM(1,k), FM(2,k), 'go','MarkerSize',10);
    % %         plot(clustCent(1,data2cluster(k)),clustCent(2,data2cluster(k)), 'rp','MarkerSize',20,'MarkerFaceColor','g');
    % % curnuclei=nuclei{k};
    % % plot(curnuclei(:,2), curnuclei(:,1), 'g-', 'LineWidth', 1);
    %         plot(nuclei{k}(:,2), nuclei{k}(:,1), 'g-', 'LineWidth', 1);
    %         % connecting line
    %         plot([clustCent(1,data2cluster(k)), FM(1,k)],[clustCent(2,data2cluster(k)), FM(2,k)],'y', 'LineWidth',1);
    %     end
    %     hold off
    coordinate_in_space=zeros(2,length(clustCent));
    for i=1:size(coordinate_in_space,2)
        coordinate_in_space(:,i)=mean(FM(:,data2cluster==i),2);
    end
    %%% colorized CG
    cmap=colormap('hsv');
    show(curIM,8);
    hold on
    numObj=size(FM,2);
    for k = 1 : numObj
        %         plot(FM(1,k), FM(2,k), 'go','MarkerSize',10);
        %         plot(clustCent(1,data2cluster(k)),clustCent(2,data2cluster(k)), 'rp','MarkerSize',20,'MarkerFaceColor','g');
        if isfield(para,'nuclei');
            plot(para.nuclei{k}(:,2), para.nuclei{k}(:,1), 'g-', 'LineWidth', 1);
        end
        % connecting line
        %         plot([clustCent(1,data2cluster(k)), FM(1,k)],[clustCent(2,data2cluster(k)), FM(2,k)],'Color',cmap(mod(data2cluster(k),size(cmap,1))+1,:), 'LineWidth',1);
        %         plot([clustCent(1,data2cluster(k)), FM(1,k)],[clustCent(2,data2cluster(k)), FM(2,k)],'Color',cmap(mod(data2cluster(k),size(cmap,1))+1,:), 'LineWidth',2);
        plot([coordinate_in_space(1,data2cluster(k)), FM(1,k)],[coordinate_in_space(2,data2cluster(k)), FM(2,k)],'Color',cmap(mod(data2cluster(k),size(cmap,1))+1,:), 'LineWidth',2);
        
    end
    hold off
    
    %%% on binary image
    %     show(bw_Nuclei,2);
    %     hold on
    %     numObj=size(FM,2);
    %     for k = 1 : numObj
    %         plot(FM(1,k), FM(2,k), 'ro','MarkerSize',10);
    %         plot(clustCent(1,data2cluster(k)),clustCent(2,data2cluster(k)), 'rp','MarkerSize',20,'MarkerFaceColor','g');
    %         % connecting line
    %         plot([clustCent(1,data2cluster(k)), FM(1,k)],[clustCent(2,data2cluster(k)), FM(2,k)], 'y','LineWidth',1);
    %     end
    %     hold off
    
    if para.num_fixed_types>1
        % show the same type of FeDeG with the same color
        coordinate_in_space=zeros(2,length(clustCent));
        for i=1:size(coordinate_in_space,2)
            coordinate_in_space(:,i)=mean(FM(:,data2cluster==i),2);
        end
        %%% colorized CG
        %         cmap=colormap('hsv');
        cmap=[1 0 0; 0 1 0; 0 0 1;1 1 0; 1 0 1; 0 1 1; 1 1 1];
        %         tmp=linspace(1,round(size(cmap,1)/3),para.num_fixed_types);
        %         cmap=cmap(tmp,:);
        cmap=cmap(1:para.num_fixed_types,:);
        
        show(curIM,9);
        hold on
        numObj=size(FM,2);
        for k = 1 : numObj
            %         plot(FM(1,k), FM(2,k), 'go','MarkerSize',10);
            %         plot(clustCent(1,data2cluster(k)),clustCent(2,data2cluster(k)), 'rp','MarkerSize',20,'MarkerFaceColor','g');
            if isfield(para,'nuclei')
                %             plot(para.nuclei{k}(:,2), para.nuclei{k}(:,1), 'g-', 'LineWidth', 1);
                plot(para.nuclei{k}(:,2), para.nuclei{k}(:,1), '-', 'Color',cmap(clust2types(data2cluster(k)),:),'LineWidth', 1);
            end
            % connecting line
            %         plot([clustCent(1,data2cluster(k)), FM(1,k)],[clustCent(2,data2cluster(k)), FM(2,k)],'Color',cmap(mod(data2cluster(k),size(cmap,1))+1,:), 'LineWidth',1);
            %         plot([clustCent(1,data2cluster(k)), FM(1,k)],[clustCent(2,data2cluster(k)), FM(2,k)],'Color',cmap(mod(data2cluster(k),size(cmap,1))+1,:), 'LineWidth',2);
            plot([coordinate_in_space(1,data2cluster(k)), FM(1,k)],[coordinate_in_space(2,data2cluster(k)), FM(2,k)],'Color',cmap(clust2types(data2cluster(k)),:), 'LineWidth',2);
        end
        hold off
    end
end
