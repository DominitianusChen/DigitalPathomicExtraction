% the bounds should have nx1 matrix, each row contain the row and col of a boundary of nuclei 
function mask=Lturn_bounds_to_mask(bounds,I)
mask= false(size(I,1),size(I,2));
for i=1:length(bounds.nuclei)
    b=bounds.nuclei{i};
    msk=poly2mask(b(:,2),b(:,1),size(I,1),size(I,2));%show(mask);
    mask=mask|msk;
end
% show(mask);
% LshowBWonIM(mask,I);