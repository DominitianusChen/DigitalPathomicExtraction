function [feats,description]=Lextract_BasicShapeinCCG_Features_precomputeCCGfile(bounds,properties,a,r,ParaC)
%% buid ccg
%
% % build graph
% alpha = a;
% % r = r;
% [VX,VY,x,y,edges] = construct_ccgs(bounds,alpha, r);
%
% CCGinfo.VX=VX;
% CCGinfo.VY=VY;
feature_names={'Area','MajorAxisLength','MinorAxisLength','Eccentricity','Orientation','EquivDiameter','Solidity','Perimeter','Circularity','EllipticalDeviation',...
    'MeanIntensity','IntensityDeviation','IntensityRange','MeanInsideBoundaryIntensity','InsideBoundaryIntensityDeviation','InsideBoundaryIntensityRange',...
    'MeanOutsideBoundaryIntensity','OutsideBoundaryIntensityDeviation','OutsideBoundaryIntensityRange','BoundarySaliency'};
modifier = [{'mean'} {'median'} {'std'} {'range'} {'kurtosis'} {'skewness'} ];
statisticinCCG_names=[{'mean'} {'median'} {'std'} {'range'}];

%% buid ccg
% will not process if not enough nuclei
if length(bounds)>5 
    if ~(isfield(ParaC,'curName')||isfield(ParaC,'CCGlocation'))
        error('please specify the image name for ccg');
    else
        str=sprintf('%s_CG_%s_a=%.2f.mat',ParaC.curName,ParaC.CCGlocation,a);
        if exist(str,'file')~=2
            % build graph
            [VX,VY,x,y,edges] = construct_ccgs(bounds,a, r);
            save(str,'VX','VY','x','y','edges','-v7.3');
        else
            load(str);
        end
    end
    
    % check
    % nodes=bounds;
    % show(I,1);hold on;
    % for x = 1: numel(nodes)
    %     plot(nodes(x).centroid_c, nodes(x).centroid_r,'yo', 'MarkerSize',2, 'MarkerFaceColor', 'g');
    % end
    % plot(VY', VX', 'g-', 'LineWidth', 1);
    % hold off;
    
    %% based on number of neighborhoods rather than number of bounds
    for j = 1:length(bounds.centroid_c)-1
        for k = j+1:length(bounds.centroid_c)
            edges(k,j) = edges(j,k);
        end
    end
    
    % find gland networks
    [numcomp,group] = graphconncomp(sparse(edges));
    
    % remove single gland networks
    temp_network = hist(group,numcomp);
    [~,group_ind] = find(temp_network > 1);
    
    %% parameters settings
    % feature_names = fieldnames(properties);
    % feature_names(2,10,13,14,21,25,27)=[];
    allBSFinCCG=[]; % save all CCM features
    % feature_names';
    % lulu dec 28
    for i=1:length(feature_names)
        cur_f=eval(['[properties.' feature_names{i} ']']);
        all_feat=[];
        for ii = 1:length(group_ind) % define a neighborhood for each gland network (number of neighborhoods = number of networks)
            curs=cur_f(group == group_ind(ii));
            all_feat(ii,:)=[mean(curs) median(curs) std(curs) range(curs)];
        end
        %% statistics: mean, median, standard deviation, range, kurtosis, skewness , across bounds for each haralick feature
        % check if the current nuclear morpholgy has no haralick features
        if ~isempty(all_feat) && size(all_feat,1)>3
            curBSFinCCG=[];
            curBSFinCCG=[mean(all_feat) median(all_feat) std(all_feat)  range(all_feat) kurtosis(all_feat) skewness(all_feat)];
            allBSFinCCG=[allBSFinCCG curBSFinCCG];
        else
            allBSFinCCG=[allBSFinCCG zeros(1,size(all_feat,2)*6)];
        end
    end
    feats=allBSFinCCG;
else
    count = 1;
    %the format is like this: morphofeaturenames_modifier_statistcinCCGname
    for m=1:length(feature_names);
        for mi = 1:numel(modifier)
            for j = 1:numel(statisticinCCG_names)
                count = count + 1;
            end
        end
    end
    feats=zeros(1,count-1);
end

%% feature names organization
count = 1;
%the format is like this: morphofeaturenames_modifier_statistcinCCGname
for m=1:length(feature_names);
    for mi = 1:numel(modifier)
        for j = 1:numel(statisticinCCG_names)
            description{count} = ['BasicShapeinCCG-' feature_names{m} ':' modifier{mi} '(' statisticinCCG_names{j} ')'  ];
            count = count + 1;
        end
    end
end

end