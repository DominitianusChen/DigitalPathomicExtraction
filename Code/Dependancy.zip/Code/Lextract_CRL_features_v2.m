% by cheng lu, on 30rd April. 2016
% calculate all cell cluster morphological/subgraphs features.
% the ccg visualization parameter are stroed in CCGinfo.
function [feats,feats_description,CGinfo] = Lextract_CRL_features_v2(bounds,I,properties,para)
% compute the mean and standard deviation of CGTs across all bounds
% c = co-occurrence matrix

CGinfo=[]; % cell graph information
feats=[];
feats_description=[];

set_alpha=[para.CGalpha_min:para.alpha_res:para.CGalpha_max];
for f=1:length(set_alpha)
    curpara.alpha=set_alpha(f); curpara.radius=para.radius;
    %     [feat,feat_description,CGinfo{f}] = Lextract_CCM_features_single_correct(bounds,I,properties,...
    %         curpara.alpha,curpara.radius);
    try        
        
    [feat,feat_description,CGinfo{f}] = Lextract_CRL_features_single(bounds,I,properties,...
        curpara.alpha,curpara.radius,para);
    catch
        disp('Out of Memory, use previous value to replace');
        if f==1
            for iff=1:24
                feat_description{iff}=num2str(curpara.alpha);
            end
            feat=ones(1,24);
        else
            feat_description=oldtemp;
            feat=oldfeat;
        end
    end
    %     CGinfo{f}=CGinfotemp;
    %%% get feature description
    temp= feat_description;
    oldtemp=feat_description;
    oldfeat=feat;
    
    for i=1:length(temp)
        cur=temp{i};
        str=sprintf('-a=%.2f',curpara.alpha);
        cur(end+1:end+length(str))=str;
        temp{i}=cur;
    end
    feats=cat(2,feats,feat); feats_description=cat(2,feats_description,temp);
    %     fprintf('%d features at %f\n', length(feat),curpara.alpha);
end

end
