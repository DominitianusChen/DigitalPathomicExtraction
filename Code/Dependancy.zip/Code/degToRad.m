function radians = degToRad(degrees)
% degToRad: Converts degrees to radians.

radians = degrees * pi / 180;

end