% this is used to remove the false positive using color rules,
% I is assumed to be a corlor image
function [nuclei,properties]=LremoveFalsePositive_from_contour_v2(nuclei,properties,I)
%% convert boundary to mask
allmeanInt=zeros(length(nuclei),1);
[m,n,k]=size(I);
for i=1:length(nuclei)
    cur=nuclei{i};
    bw = poly2mask(cur(:,2), cur(:,1), m, n) ;%show(bw);
    rr=regionprops(bw,I(:,:,1),'MeanIntensity');
    allmeanInt(i)=rr.MeanIntensity;
end

keep=find(allmeanInt<220);

% show(I);hold on;
%             for k = 1:length(keep)
%                 plot(nuclei{keep(k)}(:,2), nuclei{keep(k)}(:,1), 'g-', 'LineWidth', 1);                
%             end
%             hold off; 
            
nuclei=nuclei(keep);
properties=properties(keep);
end