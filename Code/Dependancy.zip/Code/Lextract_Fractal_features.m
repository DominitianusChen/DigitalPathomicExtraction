function [Fractalfeature,description]=Lextract_Fractal_features(bwNuclei,I,para)
% nodes=bounds;
% show(I);hold on;
% for x = 1: numel(nodes)
%
%     plot(nodes(x).centroid_c, nodes(x).centroid_r,'bo', 'MarkerSize',2, 'MarkerFaceColor', 'g');
% end
% hold off;
% allnuclei=nodes.nuclei;

% show(I);hold on;
% for i=1:length(allnuclei)
%     curN=allnuclei{i};
%     plot(curN(:,2), curN(:,1),'g');
% end
% hold off;

%% conver the nuclei boundary to binary mask
% [m,n,k]=size(I);
% bwNuclei=logical(zeros(m,n));
% for i=1:length(allnuclei)
%     curN=allnuclei{i};
%     bw=poly2mask(curN(:,2), curN(:,1),m,n);
%     bwNuclei=bwNuclei|bw;
% end
% LshowBWonIM(bwNuclei,I);
% show(bwNuclei);
%% cal the fractal dimension in different resolution
% res_set=para.resolution_set;
res_set=.25;
d_nuclei_at_40x=70;% a typical nuclei diameter in 40x image
for i=1:length(res_set)
    bwNu_resize=imresize(bwNuclei,res_set(i));
    %      bwNu_resize=imresize(bwNuclei,0.5);%show(bwNuclei);
    %     show(bwNu_resize);
    % figure;
    % boxcount( bwNu_resize)
    
    
    % [n, r] = boxcount(bwNu_resize)
    % loglog(r, n,'bo-', r, (r/r(end)).^(-2), 'r--')
    % xlabel('r')
    % ylabel('n(r)')
    % legend('actual box-count','space-filling box-count');
    
    % If the set has some fractal properties over a limited range of box size
    % R, this may be appreciated by plotting the local exponent,
    % D = - d ln N / ln R.  For this, use the option 'slope':
    %[n,r]=boxcount(bwNu_resize, 'slope'); % modified to prevent figure
    %plot
    [n,r]=boxcount(bwNu_resize);
    df = -diff(log(n))./diff(log(r));
    temp=find(r>=size(bwNu_resize,1));
    tempmin=find(r>d_nuclei_at_40x*res_set(i));
    R_range=[ tempmin(1):temp(1)-1];
%     disp(['Fractal dimension, Df = ' num2str(mean(df(R_range))) ' +/- ' num2str(std(df(R_range))) '\n']);
    FD(i,:)=df(R_range);
end
Fractalfeature=FD;
%% make description
description=[];
for i=1:length(R_range)
    description{i}=sprintf('FD-boxsize=%d',R_range(i));
end
end