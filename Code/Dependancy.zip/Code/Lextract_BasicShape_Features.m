function [feats,description]=Lextract_BasicShape_Features(properties)

feature_names={'Area','MajorAxisLength','MinorAxisLength','Eccentricity','Orientation','EquivDiameter','Solidity','Perimeter','Circularity','EllipticalDeviation',...
    'MeanIntensity','IntensityDeviation','IntensityRange','MeanInsideBoundaryIntensity','InsideBoundaryIntensityDeviation','InsideBoundaryIntensityRange',...
    'MeanOutsideBoundaryIntensity','OutsideBoundaryIntensityDeviation','OutsideBoundaryIntensityRange','BoundarySaliency'};
feats=[];

for i=1:length(feature_names)
    eval(sprintf('all_feat=[properties.%s];',feature_names{i}));
    feats=[feats mean(all_feat) median(all_feat) std(all_feat)  range(all_feat) kurtosis(all_feat) skewness(all_feat)];
end

%% feature names organization
count = 1;
modifier = [{'mean'} {'median'} {'std'} {'range'} {'kurtosis'} {'skewness'} ];
%the format is like this: featurenames_statistcname
for m=1:length(feature_names);
    for mi = 1:numel(modifier)
        description{count} = ['BasicShape-' feature_names{m} ':' modifier{mi}];
        count = count + 1;
    end
end

if length(isnan(feats))~=count-1
    feats=zeros(1,count-1);
    feats(:)=nan;
end
end